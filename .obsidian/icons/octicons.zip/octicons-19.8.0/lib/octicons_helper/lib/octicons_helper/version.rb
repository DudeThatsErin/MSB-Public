module OcticonsHelper
  VERSION = "19.8.0".freeze
end
