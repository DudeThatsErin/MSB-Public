module Octicons
  VERSION = "19.8.0".freeze
end
